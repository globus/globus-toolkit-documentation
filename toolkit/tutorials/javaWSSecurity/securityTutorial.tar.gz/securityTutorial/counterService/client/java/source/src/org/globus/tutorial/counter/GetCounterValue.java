/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.counter.client;

import org.globus.axis.gsi.GSIConstants;
import org.globus.wsrf.impl.security.authentication.Constants;
import org.globus.wsrf.impl.security.authorization.NoAuthorization;

import java.util.List;

import org.globus.tutorial.counter.GetValue;
import org.globus.tutorial.counter.CounterPortType;
import org.globus.tutorial.counter.CounterServiceAddressingLocator;

import org.globus.wsrf.client.BaseClient;
import org.globus.wsrf.utils.FaultHelper;
import org.globus.axis.util.Util;

import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.CommandLine;

import javax.xml.rpc.Stub;

public class GetCounterValue extends TutorialBaseClient {

    public GetCounterValue() {
        
        super();
        options.addOption(BaseClient.EPR_FILE);
    }

    protected void displayUsage() {
        String usage = "java " + getClass().getName() +
            " [-h] [-d] -e eprFile";
        System.out.println(usage);
    }

    protected CommandLine parse(String [] args)
        throws Exception {

       CommandLine line = super.parse(args);

        if (line.hasOption("e")) {
            this.endpoint = loadEPR(line.getOptionValue("e"));
        } else {
            throw new ParseException("-e argument is required");
        }

        return line;
    }

    public static void main(String[] args) {

        GetCounterValue client = new GetCounterValue();

        try {
            CommandLine line = client.parse(args);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(COMMAND_LINE_ERROR);
        }
      
        CounterServiceAddressingLocator locator =
            new CounterServiceAddressingLocator();

        try {
            CounterPortType port = 
                locator.getCounterPortTypePort(client.getEPR());

            setSecurityProperties((Stub)port);

            int value = port.getValue(new GetValue());
            System.out.println("Current counter value " + value);
        } catch(Exception e) {
            if (client.isDebugMode()) {
                FaultHelper.printStackTrace(e);
            } else {
                System.err.println("Error: " + FaultHelper.getMessage(e));
            }
            System.exit(APPLICATION_ERROR);
        }
    }

    private static void setSecurityProperties(Stub stub) {

        /** UNCOMMENT FOR EXERCISE 2 */
        /**
        stub._setProperty(GSIConstants.GSI_TRANSPORT,
                          Constants.ENCRYPTION);
        */
        /** END UNCOMMENT FOR EXERCISE 2 */

        /** UNCOMMENT FOR EXERCISE 7 */
        /**
        stub._setProperty(Constants.GSI_ANONYMOUS, Boolean.TRUE);
        */
        /** END OF UNCOMMENT FOR EXERCISE 7 */

        /** UNCOMMENT FOR EXERCISE 8 */
        /**
        stub._setProperty(Constants.GSI_SEC_MSG,
                          Constants.SIGNATURE);
        */
        /** END UNCOMMENT FOR EXERCISE 8 */



        stub._setProperty(Constants.AUTHORIZATION,
                          NoAuthorization.getInstance());
    }        
}
