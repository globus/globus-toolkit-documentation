/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.counter.client;

import org.globus.axis.gsi.GSIConstants;
import org.globus.wsrf.impl.security.authentication.Constants;
import org.globus.wsrf.impl.security.authorization.NoAuthorization;

import java.util.List;

import org.globus.tutorial.counter.CounterPortType;
import org.globus.tutorial.counter.CounterServiceAddressingLocator;

import org.globus.wsrf.client.BaseClient;
import org.globus.wsrf.utils.FaultHelper;
import org.globus.axis.util.Util;

import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.CommandLine;

import javax.xml.rpc.Stub;

import org.apache.axis.message.addressing.EndpointReferenceType;

public class Add extends TutorialBaseClient {

    private String descriptorFile = null;

    public Add() {
        
        super();
        options.addOption(BaseClient.EPR_FILE);
        options.addOption(BaseClient.DESCRIPTOR);
    }

    protected void displayUsage() {
        String usage = "java " + getClass().getName() +
            " [-h] [-d] [-f descriptor] -e eprFile value ";
        System.out.println(usage);
    }

    protected CommandLine parse(String [] args)
        throws Exception {

       CommandLine line = super.parse(args);

        if (line.hasOption("e")) {
            this.endpoint = loadEPR(line.getOptionValue("e"));
        } else {
            throw new ParseException("-e argument is required");
        }

        if (line.hasOption("f")) {
            String value = line.getOptionValue("f");
            this.descriptorFile = value;
        }

        return line;
    }

    public String getDescriptorFile() {
        return this.descriptorFile;
    }

    public static void main(String[] args) {
        Add client = new Add();

        int value = 0;

        try {
            CommandLine line = client.parse(args);
            
            List options = line.getArgList();
            if (options == null || options.isEmpty()) {
                throw new ParseException("Expected value argument");
            }
            value = Integer.parseInt((String)options.get(0));
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(COMMAND_LINE_ERROR);
        }
      
        CounterServiceAddressingLocator locator =
            new CounterServiceAddressingLocator();

        try {
            CounterPortType port = 
                locator.getCounterPortTypePort(client.getEPR());

            setSecurityProperties((Stub)port, client.getDescriptorFile());

            port.add(value);
            System.out.println("Value " + value + " added");
        } catch(Exception e) {
            if (client.isDebugMode()) {
                FaultHelper.printStackTrace(e);
            } else {
                System.err.println("Error: " + FaultHelper.getMessage(e));
            }
            System.exit(APPLICATION_ERROR);
        }
    }

    private static void setSecurityProperties(Stub stub, 
                                              String descriptorFile) {

        /** UNCOMMENT FOR EXERCISE 2 */
        /**
        if (descriptorFile != null) {
            stub._setProperty(Constants.CLIENT_DESCRIPTOR_FILE,
                              descriptorFile);
        }
        */
        /** END UNCOMMENT FOR EXERCISE 2 */

        /** COMMENT FOR EXERCISE 2 */
        
        stub._setProperty(Constants.AUTHORIZATION,
                          NoAuthorization.getInstance());

        /** END COMMENT FOR EXERCISE 2 */
    }    
}
