/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.counter.client;

import org.globus.axis.gsi.GSIConstants;
import org.globus.wsrf.impl.security.authentication.Constants;
import org.globus.wsrf.impl.security.authorization.SelfAuthorization;

import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.HashMap;

import org.globus.wsrf.container.ServiceContainer;

import org.globus.tutorial.counter.notifications.NotificationCounterPortType;
import org.globus.tutorial.counter.notifications.CounterServiceAddressingLocator;

import org.globus.wsrf.client.BaseClient;
import org.globus.wsrf.utils.FaultHelper;
import org.globus.axis.util.Util;

import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.CommandLine;

import javax.xml.rpc.Stub;

import org.apache.axis.message.addressing.EndpointReferenceType;

import org.oasis.wsrf.lifetime.Destroy;
import org.oasis.wsrf.properties.ResourcePropertyValueChangeNotificationType;
import org.globus.wsrf.NotificationConsumerManager;
import org.globus.wsrf.NotifyCallback;
import org.globus.wsrf.WSNConstants;
import org.globus.wsrf.core.notification.ResourcePropertyValueChangeNotificationElementType;
import org.globus.wsrf.core.notification.SubscriptionManager;
import org.globus.wsrf.core.notification.service.SubscriptionManagerServiceAddressingLocator;

import org.globus.wsrf.impl.security.authorization.Authorization;
import org.globus.wsrf.impl.security.descriptor.GSISecureConvAuthMethod;
import org.globus.wsrf.impl.security.descriptor.GSISecureMsgAuthMethod;
import org.globus.wsrf.impl.security.descriptor.GSITransportAuthMethod;
import org.globus.wsrf.impl.security.descriptor.ResourceSecurityDescriptor;

import org.globus.tutorial.impl.counter.NotificationCounterResource;

import org.oasis.wsn.Subscribe;
import org.oasis.wsn.TopicExpressionType;

public class AddWithNotifications  {

    public static final int COMMAND_LINE_ERROR = 1;
    public static final int APPLICATION_ERROR = 2;

    public static void main(String[] args) {

        Add client = new Add();

        int value = 0;

        try {
            CommandLine line = client.parse(args);
            
            List options = line.getArgList();
            if (options == null || options.isEmpty()) {
                throw new ParseException("Expected value argument");
            }
            value = Integer.parseInt((String)options.get(0));
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(COMMAND_LINE_ERROR);
        }

        EndpointReferenceType counterEpr = client.getEPR();

        CounterServiceAddressingLocator locator =
            new CounterServiceAddressingLocator();

        NotificationConsumerManager consumer = null;

        /** UNCOMMENT FOR EXERCISE 5 */
        /**
        try {

            // Create notification consumer manager. If contacting a
            // secure container, use https consumer
            String scheme = counterEpr.getAddress().getScheme();
            if (scheme.equals("https")) {
                Map properties = new HashMap();
                properties
                    .put(ServiceContainer.CLASS,
                         "org.globus.wsrf.container.GSIServiceContainer");
                consumer = NotificationConsumerManager.getInstance(properties);
            } else {
                consumer = NotificationConsumerManager.getInstance();
            }
            // Start embedded container
            consumer.startListening();

            // Create instance of callback that the notification
            // producer should invoke
            NotificationCallback callback = new NotificationCallback();

            // On the consumer service in embedded service create an
            // instance to handle this particular notification and
            // register the callback that needs to be invoked. The EPR
            // to this resource is the consumer EPR that is sent to
            // the producer.
            EndpointReferenceType consumerEPR = null;

            // Set security on the subscription resource created to
            // ensure only expected service is sending notifications
            // This is optional
            ResourceSecurityDescriptor resDesc =
                new ResourceSecurityDescriptor();
            String authz = Authorization.AUTHZ_SELF;
            resDesc.setAuthz(authz);
            
            Vector authMethod = new Vector();
            authMethod.add(GSISecureMsgAuthMethod.BOTH);
            authMethod.add(GSISecureConvAuthMethod.BOTH);
            authMethod.add(GSITransportAuthMethod.BOTH);
            resDesc.setAuthMethods(authMethod, true);
            
            consumerEPR =
                consumer.createNotificationConsumer(callback, resDesc);

            // get counter service port to subscribe
            NotificationCounterPortType port = 
                locator.getNotificationCounterPortTypePort(counterEpr);

            // set security on port (GSI Secure Conversation, since
            // service expects that)
            setSecurityProperties((Stub)port, client.getDescriptorFile());

            // Subscribe request
            Subscribe request = new Subscribe();
            request.setUseNotify(Boolean.TRUE);
            request.setConsumerReference(consumerEPR);
            TopicExpressionType topicExpression = new TopicExpressionType();
            topicExpression.setDialect(WSNConstants.SIMPLE_TOPIC_DIALECT);
            topicExpression.setValue(NotificationCounterResource.VALUE);
            request.setTopicExpression(topicExpression);

            // susbscribe and save the subscription EPR to be able to
            // destroy it once notification is received.
            EndpointReferenceType subscriptionEPR =
                port.subscribe(request).getSubscriptionReference();

            // add value. this triggers a notification.
            port.add(value);
            System.out.println("Value " + value + " added");
            System.out.println("Waiting for notifications");

            // wait for callback
            synchronized (callback) {
                callback.wait(1000 * 30);
                if (!callback.isCalled()) {
                    System.err.println("Did not receive notification in time");
                }
            }
        } catch(Exception e) {
            if (client.isDebugMode()) {
                FaultHelper.printStackTrace(e);
            } else {
                System.err.println("Error: " + FaultHelper.getMessage(e));
            }
            System.exit(APPLICATION_ERROR);
        }
        */
        /** END UNCOMMENT FOR EXERCISE 5 */
    }

    private static void setSecurityProperties(Stub stub, 
                                              String descriptorFile) {
 
        stub._setProperty(Constants.GSI_SEC_CONV,
                          Constants.ENCRYPTION);       
        stub._setProperty(Constants.AUTHORIZATION,
                          SelfAuthorization.getInstance());

    }    

    public static class NotificationCallback implements NotifyCallback {

        private boolean called = false;

        public boolean isCalled() {
            return this.called;
        }

        public void deliver(List topicPath,
                            EndpointReferenceType producer,
                            Object message) {
            
            ResourcePropertyValueChangeNotificationType changeMessage =
                ((ResourcePropertyValueChangeNotificationElementType) message).
                getResourcePropertyValueChangeNotification();
            
            if(changeMessage != null) {
                System.out.println("Got notification with value: " +
                                   changeMessage.getNewValue().get_any()[0]
                                   .getValue());
            }
            synchronized (this) {
            called = true;
            notify();
            }
        }
        
    }
}
