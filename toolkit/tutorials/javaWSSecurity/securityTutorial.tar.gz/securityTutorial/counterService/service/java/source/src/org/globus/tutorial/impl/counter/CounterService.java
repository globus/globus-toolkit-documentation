/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.impl.counter;

import java.rmi.RemoteException;

import org.apache.axis.message.addressing.EndpointReferenceType;

import org.globus.wsrf.ResourceContext;
import org.globus.wsrf.ResourceKey;
import org.globus.wsrf.utils.AddressingUtils;

import org.globus.tutorial.counter.GetValue;
import org.globus.tutorial.counter.CreateCounter;
import org.globus.tutorial.counter.CreateCounterResponse;
import org.globus.tutorial.counter.AddAuthzDNResponse;

/**
 * Counter service implementation.
 */
public class CounterService {

    public CreateCounterResponse createCounter(CreateCounter request)
        throws RemoteException {
        ResourceContext ctx = null;
        CounterHome home = null;
        ResourceKey key = null;

        try {
            ctx = ResourceContext.getResourceContext();
            home = (CounterHome) ctx.getResourceHome();
            key = home.create();
        }  catch(Exception e) {
            throw new RemoteException("", e);
        }

        EndpointReferenceType epr = null;
        try {
            epr = AddressingUtils.createEndpointReference(ctx, key);
        } catch(Exception e) {
            throw new RemoteException("", e);
        }

        CreateCounterResponse response = new CreateCounterResponse();
        response.setEndpointReference(epr);

        return response;
    }

    public void add(int arg0) throws RemoteException {
        Object resource = null;
        try {
            resource = ResourceContext.getResourceContext().getResource();
        } catch(Exception e) {
            throw new RemoteException("", e);
        }

        CounterResource counter = (CounterResource) resource;
        counter.add(arg0);
    }

    public void subtract(int arg0) throws RemoteException {
        Object resource = null;
        try {
            resource = ResourceContext.getResourceContext().getResource();
        } catch(Exception e) {
            throw new RemoteException("", e);
        }

        CounterResource counter = (CounterResource) resource;
        counter.subtract(arg0);
    }

    public int getValue(GetValue value) throws RemoteException {

        Object resource = null;
        try {
            resource = ResourceContext.getResourceContext().getResource();
        } catch(Exception e) {
            throw new RemoteException("", e);
        }

        CounterResource counter = (CounterResource) resource;
        return counter.getValue();
    }

    public AddAuthzDNResponse addAuthorizedDN(String parameters) 
        throws RemoteException {
        
        throw new RemoteException("Not implemented");
    }
}
