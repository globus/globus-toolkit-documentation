/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.impl.counter;

import java.util.Calendar;

import org.globus.wsrf.Resource;
import org.globus.wsrf.ResourceKey;
import org.globus.wsrf.ResourceIdentifier;
import org.globus.wsrf.ResourceLifetime;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CounterResource implements Resource, ResourceLifetime, 
                                        ResourceIdentifier {
    
    protected Calendar terminationTime = null;
    protected Object key;

    static Log logger =
        LogFactory.getLog(CounterResource.class.getName());

    private int value = 0;

    public void create() throws Exception {
        this.key = new Integer(hashCode());
    }

    public synchronized void add(int data) {
        setValue(this.value + data);
    }

    public synchronized void subtract(int data) {
        setValue(this.value - data);
    }

    protected void setValue(int data) {
        this.value = data;
    }

    public int getValue() {
        return this.value;
    }

    public Object getID() {
        return this.key;
    }

    public void setTerminationTime(Calendar time) {
        this.terminationTime = time;
    }

    public Calendar getTerminationTime() {
        return this.terminationTime;
    }

    public Calendar getCurrentTime() {
        return Calendar.getInstance();
    }

}
