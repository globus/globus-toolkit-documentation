/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.impl.counter;

import org.globus.gsi.CertUtil;

import java.util.Calendar;

import org.globus.wsrf.Resource;
import org.globus.wsrf.ResourceKey;
import org.globus.wsrf.ResourceIdentifier;
import org.globus.wsrf.ResourceLifetime;

import org.globus.security.gridmap.GridMap;
import org.globus.wsrf.security.SecureResource;
import org.globus.wsrf.security.SecurityManager;
import org.globus.wsrf.impl.security.descriptor.ResourceSecurityConfig;
import org.globus.wsrf.impl.security.descriptor.ResourceSecurityDescriptor;

import org.globus.wsrf.impl.security.authorization.ResourcePDPConfig;
import org.globus.wsrf.impl.security.authorization.GridMapAuthorization;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.xml.namespace.QName;

import org.globus.wsrf.Topic;
import org.globus.wsrf.TopicList;
import org.globus.wsrf.TopicListAccessor;

import org.globus.wsrf.ResourceProperties;
import org.globus.wsrf.ResourceProperty;
import org.globus.wsrf.ResourcePropertySet;
import org.globus.wsrf.impl.ResourcePropertyTopic;
import org.globus.wsrf.impl.SimpleResourcePropertySet;
import org.globus.wsrf.impl.SimpleTopicList;
import org.globus.wsrf.impl.SimpleTopic;
import org.globus.wsrf.impl.SimpleResourceProperty;

public class NotificationCounterResource extends SecureCounterResource 
    /** UNCOMMENT FOR EXERCISE 5 */                                       
    /**                                                 
    implements  ResourceProperties,TopicListAccessor
    */
    /** END UNCOMMENT FOR EXERCISE 5 */
{

    static Log logger =
        LogFactory.getLog(NotificationCounterResource.class.getName());


    public static final String NS = 
        "http://www.globus.org/counter/notifications";

    public static final QName RP_SET = new QName(NS, "CounterRP");

    public static final QName VALUE = new QName(NS, "Value");

    ResourceProperty valueRp= 
        new ResourcePropertyTopic(new SimpleResourceProperty(VALUE));

    private ResourcePropertySet propSet;
    private TopicList topicList;

    public void initialize(String descriptorFile) throws Exception {
        
        super.initialize(descriptorFile);
        
        System.out.println("Notification Counter Resource");

        /** UNCOMMENT FOR EXERCISE 5 */
        /**
        this.propSet = new SimpleResourcePropertySet(RP_SET);
        this.topicList = new SimpleTopicList(this);
        this.topicList.addTopic((Topic) this.valueRp);
        this.valueRp.add(new Integer(0));
        this.propSet.add(this.valueRp);
        */
        /** END OF UNCOMMENT FOR EXERCISE 5 */
    }

    public ResourcePropertySet getResourcePropertySet() {
        return this.propSet;
    }

    public TopicList getTopicList() {
        return this.topicList;
    }

    protected void setValue(int data) {
        
        super.setValue(data);
        this.valueRp.set(0, new Integer(data));
    }
}
