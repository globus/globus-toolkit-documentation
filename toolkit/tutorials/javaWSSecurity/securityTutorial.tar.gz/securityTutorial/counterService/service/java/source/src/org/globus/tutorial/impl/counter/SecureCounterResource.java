/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.impl.counter;

import org.globus.gsi.CertUtil;

import java.util.Calendar;

import org.globus.wsrf.Resource;
import org.globus.wsrf.ResourceKey;
import org.globus.wsrf.ResourceIdentifier;
import org.globus.wsrf.ResourceLifetime;

import org.globus.security.gridmap.GridMap;
import org.globus.wsrf.security.SecureResource;
import org.globus.wsrf.security.SecurityManager;
import org.globus.wsrf.impl.security.descriptor.ResourceSecurityConfig;
import org.globus.wsrf.impl.security.descriptor.ResourceSecurityDescriptor;

import org.globus.wsrf.impl.security.authorization.ResourcePDPConfig;
import org.globus.wsrf.impl.security.authorization.GridMapAuthorization;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class SecureCounterResource extends CounterResource 

    /** UNCOMMENT FOR EXERCISE 4 */                                       
    /**
    implements SecureResource 
    */
    /** END UNCOMMENT FOR EXERCISE 4 */
{
    ResourceSecurityDescriptor desc = null;

    static Log logger =
        LogFactory.getLog(SecureCounterResource.class.getName());

    String pdpPrefix = "localPdp1";

    public void initialize(String descriptorFile) throws Exception {

        create();

        /** UNCOMMENT FOR EXERCISE 4 */
        /**
        // Read the security descriptor from file and initialize a
        // ResourceSecurityDescriptor object.
        ResourceSecurityConfig config = 
            new ResourceSecurityConfig(descriptorFile);
        config.init();
        this.desc = config.getSecurityDescriptor();

        // The descriptor file had self authorization. Change that to
        // use Gridmap Authporization. Note this is a gridmap file
        // just for this resource and we don't really use the mapping
        // (so can be dummy)
        String pdpChain = pdpPrefix + ":" + 
            GridMapAuthorization.class.getName();

        ResourcePDPConfig pdpConfig = new ResourcePDPConfig(pdpChain);
        this.desc.setAuthzChain(pdpChain, pdpConfig, null, null);

        // Get resource creator's DN to add to gridmap
        SecurityManager manager = SecurityManager.getManager();
        String peerDN = manager.getCaller();

        // Initialize gridmap object with creator's DN
        GridMap map = new GridMap();
        map.map(peerDN, "dummy");
        this.desc.setGridMap(map);
        */
        /** END UNCOMMENT FOR EXERCISE 4 */        
    }

    /** UNCOMMENT FOR EXERCISE 4 */
    /**
    public ResourceSecurityDescriptor getSecurityDescriptor() {
        return desc;
    }

    public void addAuthorizedDN(String dn) {
        
        if (!dn.startsWith("/")) {
            dn = CertUtil.toGlobusID(dn, true);
        }
        GridMap map = this.desc.getGridMap();
        map.map(dn, "dumy");
    }
    */
    /** END UNCOMMENT FOR EXERCISE 4 */        
}
