/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.finance.client;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;

import org.apache.axis.message.addressing.Address;
import org.apache.axis.message.addressing.EndpointReferenceType;

import javax.xml.rpc.Stub;

import org.globus.wsrf.encoding.ObjectSerializer;
import org.globus.wsrf.utils.FaultHelper;
import org.globus.axis.util.Util;

import javax.xml.namespace.QName;

import org.globus.wsrf.client.BaseClient;

import java.util.Properties;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;

import java.io.FileWriter;
import java.io.FileInputStream;

import org.xml.sax.InputSource;

import org.globus.wsrf.encoding.ObjectDeserializer;

import org.globus.axis.gsi.GSIConstants;
import org.globus.wsrf.impl.security.authentication.Constants;
import org.globus.wsrf.impl.security.authorization.NoAuthorization;

public abstract class TutorialBaseClient {

    public static final int COMMAND_LINE_ERROR = 1;
    public static final int APPLICATION_ERROR = 2;

    private String descriptorFile = null;
    protected String factoryUrl = null;
    protected String resultEprFile = null;
    protected EndpointReferenceType endpoint;
    protected boolean debugMode;
    protected Options options = new Options();

    /** UNCOMMENT FOR EXERCISE 10 */
    /**
    protected  static String FINANCE_SERVICE = "FinanceService";
    */
    /** UNCOMMENT FOR EXERCISE 10 */

    static {
        Util.registerTransport();
    }

    public static final Option HELP =
        OptionBuilder.withDescription("Displays help")
        .withLongOpt("help")
        .create("h");

    public static final Option RESULT_EPR_FILE =
        OptionBuilder.withArgName( "file" )
        .hasArg()
        .withDescription("Writes EPR to file")
        .withLongOpt("resultEprFile")
        .create("o");

    public static final Option SERVICE_URL =
        OptionBuilder.withArgName( "url" )
        .hasArg()
        .withDescription("Factory Service URL")
        .withLongOpt("factory")
        .create("s");

    public TutorialBaseClient() {

        options.addOption(HELP);
        options.addOption(BaseClient.DEBUG);
    }

    public String getDescriptorFile() {
        return this.descriptorFile;
    }

    public String getEPRResultEPR() {
        return this.resultEprFile;
    }

    public EndpointReferenceType getEPR() {
        return this.endpoint;
    }

    public boolean isDebugMode() {
        return this.debugMode;
    }

    public String getFactoryUrl() {
        return this.factoryUrl;
    }

    protected abstract void displayUsage();

    protected CommandLine parse(String [] args)
        throws Exception {

        CommandLineParser parser = new PosixParser();
        CommandLine line = parser.parse(options, args, null);

        if (line.hasOption("h")) {
            displayUsage();
            System.exit(0);
        }

        this.debugMode = line.hasOption("d");

        if (line.hasOption("f")) {
            String value = line.getOptionValue("f");
            this.descriptorFile = value;
        }

        return line;

    }

    public static EndpointReferenceType loadEPR(String file) throws Exception {
        
        FileInputStream in = null;
        try {
            in = new FileInputStream(file);
            return (EndpointReferenceType)ObjectDeserializer
                .deserialize(new InputSource(in),
                             EndpointReferenceType.class);
        } finally {
            if (in != null) {
                try { in.close(); } catch (Exception e) {}
            }
        }
    }

    public static void setSecurityProperties(Stub stub, 
                                             String descriptorFile) {

        if (descriptorFile != null) {
            stub._setProperty(Constants.CLIENT_DESCRIPTOR_FILE,
                              descriptorFile);
        }

        /** COMMENT FOR EXERCISE 10 */

        stub._setProperty(Constants.AUTHORIZATION,
                          NoAuthorization.getInstance());

        /** COMMENT FOR EXERCISE 10 */
    }
}

