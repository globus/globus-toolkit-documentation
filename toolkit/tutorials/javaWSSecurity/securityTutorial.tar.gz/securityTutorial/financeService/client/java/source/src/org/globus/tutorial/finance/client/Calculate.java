/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.finance.client;

import java.math.BigDecimal;

import org.globus.wsrf.client.BaseClient;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;

import org.apache.axis.message.addressing.Address;
import org.apache.axis.message.addressing.EndpointReferenceType;

import javax.xml.rpc.Stub;

import org.globus.wsrf.encoding.ObjectSerializer;
import org.globus.wsrf.utils.FaultHelper;
import org.globus.axis.util.Util;

import javax.xml.namespace.QName;

import java.util.List;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;

import java.io.FileWriter;

import org.globus.axis.gsi.GSIConstants;
import org.globus.wsrf.impl.security.authentication.Constants;
import org.globus.wsrf.impl.security.authorization.NoAuthorization;
import org.globus.wsrf.impl.security.authorization.SelfAuthorization;

import org.globus.tutorial.financeService.FinancePortType;
import org.globus.tutorial.financeService.FinanceServiceAddressingLocator;

public class Calculate extends TutorialBaseClient {

    public Calculate() {

        super();
        options.addOption(BaseClient.EPR_FILE);
        options.addOption(RESULT_EPR_FILE);
        options.addOption(BaseClient.DESCRIPTOR);
    }

    protected void displayUsage() {
        String usage = "java " + getClass().getName() +
            " [-h] [-d] [-f securityDescFile] -e financeEPR rate years";
        System.out.println(usage);
    }

    protected CommandLine parse(String [] args)
        throws Exception {

        CommandLine line = super.parse(args);

        if (line.hasOption("e")) {
            this.endpoint = TutorialBaseClient
                .loadEPR((String)line.getOptionValue("e"));
        } else {
            throw new ParseException("Option -e with financeEPR required");
        }

        return line;
    }

    public static void main(String[] args) {

        Calculate client = new Calculate();

        BigDecimal rate = null;
        int years = 0;

        try {
            CommandLine line = client.parse(args);
            List options = line.getArgList();
            if (options == null || options.size() < 2) {
                client.displayUsage();
                throw new ParseException("Expected arguments");
            }
            rate = new BigDecimal((String)options.get(0));
            years = Integer.parseInt((String)options.get(1));
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(COMMAND_LINE_ERROR);
        }

        FinanceServiceAddressingLocator locator =
            new FinanceServiceAddressingLocator();

        try {
            FinancePortType port = 
                locator.getFinancePortTypePort(client.getEPR());

            setSecurityProperties((Stub)port, client.getDescriptorFile());

            org.globus.tutorial.financeService.Calculate param = 
                new org.globus.tutorial.financeService.Calculate();
            param.setRate(rate);
            param.setYears(years);
                
            BigDecimal value = port.calculate(param);
            
            System.out.println("At a rate of " + rate + "% ,in " + years 
                               + " years your return will be " + value);
        } catch(Exception e) {
            if (client.isDebugMode()) {
                FaultHelper.printStackTrace(e);
            } else {
                System.err.println("Error: " + FaultHelper.getMessage(e));
            }
            System.exit(APPLICATION_ERROR);
        }
    }
}
