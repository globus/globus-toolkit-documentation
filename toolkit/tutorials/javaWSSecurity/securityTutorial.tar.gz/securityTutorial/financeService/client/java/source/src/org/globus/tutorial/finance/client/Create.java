/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.finance.client;

import org.globus.wsrf.client.BaseClient;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;

import org.apache.axis.message.addressing.Address;
import org.apache.axis.message.addressing.EndpointReferenceType;

import javax.xml.rpc.Stub;

import org.globus.wsrf.encoding.ObjectSerializer;
import org.globus.wsrf.utils.FaultHelper;
import org.globus.axis.util.Util;

import javax.xml.namespace.QName;

import java.util.List;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;

import java.io.FileWriter;

import org.globus.axis.gsi.GSIConstants;
import org.globus.wsrf.impl.security.authentication.Constants;
import org.globus.wsrf.impl.security.authorization.NoAuthorization;
import org.globus.wsrf.impl.security.authorization.HostAuthorization;

import org.globus.tutorial.financeService.FinancePortType;
import org.globus.tutorial.financeService.FinanceServiceAddressingLocator;

public class Create extends TutorialBaseClient {

    public Create() {

        super();
        options.addOption(SERVICE_URL);
        options.addOption(RESULT_EPR_FILE);
    }

    private static final QName NAME =
        new QName("http://www.globus.org/tutorial/finance", 
                  "FinanceResourceReference");

    protected void displayUsage() {
        String usage = "java " + getClass().getName() +
            " [-h] [-d] [-o resultEPRFile] -s url "
            + "bankServiceEPR  delegatedCredEPR";
        System.out.println(usage);
    }

    protected CommandLine parse(String [] args)
        throws Exception {

        CommandLine line = super.parse(args);

        if (line.hasOption("s")) {
            this.endpoint = new EndpointReferenceType();
            this.endpoint.setAddress(new Address(line.getOptionValue("s")));
        } else {
            throw new ParseException("-s argument is required");
        }

        if (line.hasOption("o")) {
            this.resultEprFile = line.getOptionValue("o");
        }
        return line;
    }

    public static void main(String[] args) {

        Create client = new Create();
        EndpointReferenceType bankServiceEPR = null;
        EndpointReferenceType delegCredEPR = null;

        try {
            CommandLine line = client.parse(args);
            List options = line.getArgList();
            if (options == null || options.size() < 2 ) {
                client.displayUsage();
                throw new ParseException("Expected arguments");
            }
            bankServiceEPR = TutorialBaseClient
                .loadEPR((String)options.get(0));
            delegCredEPR = TutorialBaseClient
                .loadEPR((String)options.get(1));
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(COMMAND_LINE_ERROR);
        }

        FinanceServiceAddressingLocator locator =
            new FinanceServiceAddressingLocator();

        try {
            FinancePortType port = 
                locator.getFinancePortTypePort(client.getEPR());

            setSecurityProperties((Stub)port);

            org.globus.tutorial.financeService.Create create = 
                new org.globus.tutorial.financeService.Create();
            create.setBankAccountEPR(bankServiceEPR);
            create.setDelegatedCredEPR(delegCredEPR);
                
            EndpointReferenceType epr = port.create(create);

            String eprStr = ObjectSerializer.toString(epr, NAME);

            String resultEPR = client.getEPRResultEPR();
            if (resultEPR != null) {
                FileWriter writer = null;
                try {
                    writer = new FileWriter(resultEPR);
                    writer.write(eprStr);
                } finally {
                    try {
                        writer.close();
                    } catch (Exception e) {}
                }
                System.out.println("Finance resource created. EPR written to "
                                   + " file: " + resultEPR);
            } else {
                System.out.println(eprStr);
            }
        } catch(Exception e) {
            if (client.isDebugMode()) {
                FaultHelper.printStackTrace(e);
            } else {
                System.err.println("Error: " + FaultHelper.getMessage(e));
            }
            System.exit(APPLICATION_ERROR);
        }
    }

    public static void setSecurityProperties(Stub stub) {

        /** UNCOMMENT FOR EXERCISE 10 */
        /**
        stub._setProperty(Constants.GSI_SEC_CONV,
                          Constants.SIGNATURE);
        stub._setProperty(Constants.AUTHORIZATION,
                          new HostAuthorization(FINANCE_SERVICE));
        */
        /** UNCOMMENT FOR EXERCISE 10 */

        /** COMMENT FOR EXERCISE 10 */

        stub._setProperty(Constants.AUTHORIZATION,
                          NoAuthorization.getInstance());

        /** COMMENT FOR EXERCISE 10 */
    }
}
