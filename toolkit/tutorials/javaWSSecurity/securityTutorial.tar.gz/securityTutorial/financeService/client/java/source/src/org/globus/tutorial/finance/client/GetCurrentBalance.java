/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.finance.client;

import java.math.BigDecimal;

import org.globus.axis.gsi.GSIConstants;
import org.globus.wsrf.impl.security.authentication.Constants;
import org.globus.wsrf.impl.security.authorization.NoAuthorization;
import org.globus.wsrf.impl.security.authorization.HostAuthorization;

import java.util.List;

import org.globus.tutorial.financeService.GetValue;
import org.globus.tutorial.financeService.FinancePortType;
import org.globus.tutorial.financeService.FinanceServiceAddressingLocator;

import org.globus.wsrf.client.BaseClient;
import org.globus.wsrf.utils.FaultHelper;
import org.globus.axis.util.Util;

import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.CommandLine;

import javax.xml.rpc.Stub;

import java.util.List;

import java.net.URL;

import org.apache.axis.message.addressing.Address;
import org.apache.axis.message.addressing.EndpointReferenceType;

public class GetCurrentBalance extends TutorialBaseClient {

    public GetCurrentBalance() {
        
        super();
        options.addOption(BaseClient.EPR_FILE);
        options.addOption(SERVICE_URL);
    }

    protected void displayUsage() {
        String usage = "java " + getClass().getName() 
            + "[-h] [-d] -s serviceURL "
            + "bankAccountEprFile delegEPRFile\n";
        System.out.println(usage);
    }

    protected CommandLine parse(String [] args)
        throws Exception {

       CommandLine line = super.parse(args);

       if (line.hasOption("s")) {
           this.endpoint = new EndpointReferenceType();
           this.endpoint.setAddress(new Address(line.getOptionValue("s")));
       } else {
           throw new ParseException("--s to access Finance Service required");
       }

        return line;
    }

    public static void main(String[] args) throws Exception {

        GetCurrentBalance client = new GetCurrentBalance();

        CommandLine line = null;
        try {
            line = client.parse(args);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(COMMAND_LINE_ERROR);
        }

        List options = line.getArgList();
        try {
            if (options == null || options.size() < 2) {
                client.displayUsage();
                throw new ParseException("Expected arguments");
            } 
            
            EndpointReferenceType bankAccountEPR = 
                TutorialBaseClient.loadEPR((String)options.get(0));
            EndpointReferenceType delegServiceEPR = 
                TutorialBaseClient.loadEPR((String)options.get(1));


            FinanceServiceAddressingLocator locator =
                new FinanceServiceAddressingLocator();
            
            FinancePortType port = 
                locator.getFinancePortTypePort(client.getEPR());
            
            setSecurityProperties((Stub)port);
            
            GetValue getValue = new GetValue();
            getValue.setBankAccountEPR(bankAccountEPR);
            getValue.setDelegatedCredEPR(delegServiceEPR);
            
            BigDecimal value = port.getValue(getValue);
            
            System.out.println("Current balance: " + value);
        } catch(Exception e) {
            if (client.isDebugMode()) {
                FaultHelper.printStackTrace(e);
            } else {
                System.err.println("Error: " + FaultHelper.getMessage(e));
            }
            System.exit(APPLICATION_ERROR);
        }
    }

    public static void setSecurityProperties(Stub stub) {

        /** UNCOMMENT FOR EXERCISE 10 */
        /**
        stub._setProperty(Constants.GSI_SEC_CONV,
                          Constants.SIGNATURE);
        stub._setProperty(Constants.AUTHORIZATION,
                          new HostAuthorization(FINANCE_SERVICE));
        */
        /** UNCOMMENT FOR EXERCISE 10 */

        /** COMMENT FOR EXERCISE 10 */

        stub._setProperty(Constants.AUTHORIZATION,
                          NoAuthorization.getInstance());

        /** COMMENT FOR EXERCISE 10 */
    }
}
