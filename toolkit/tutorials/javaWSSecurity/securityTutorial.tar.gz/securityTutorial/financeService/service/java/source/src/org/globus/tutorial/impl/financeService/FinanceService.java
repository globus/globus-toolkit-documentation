/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.impl.financeService;

import java.math.BigDecimal;

import org.ietf.jgss.GSSCredential;

import org.globus.tutorial.financeService.Create;
import org.globus.tutorial.financeService.Calculate;
import org.globus.tutorial.financeService.GetValue;

import org.globus.tutorial.bankService.GetCurrentBalance;

import java.rmi.RemoteException;

import org.apache.axis.message.addressing.EndpointReferenceType;

import org.globus.wsrf.ResourceContext;
import org.globus.wsrf.ResourceKey;

import org.globus.wsrf.utils.AddressingUtils;

import javax.xml.rpc.Stub;

import org.globus.axis.gsi.GSIConstants;
import org.globus.wsrf.impl.security.authentication.Constants;
import org.globus.wsrf.impl.security.authorization.NoAuthorization;

import org.globus.gsi.gssapi.GlobusGSSCredentialImpl;
import org.globus.gsi.GlobusCredential;

import org.globus.delegation.DelegationUtil;
import org.globus.delegation.DelegationException;
import org.globus.delegation.service.DelegationResource;

import org.globus.tutorial.bankService.BankPortType;
import org.globus.tutorial.bankService.BankServiceAddressingLocator;

public class FinanceService {

    public EndpointReferenceType create(Create parameters) 
        throws RemoteException {

        ResourceKey resourceKey;
        ResourceContext ctx;

        try {
            ctx = ResourceContext.getResourceContext();
            FinanceHome home = (FinanceHome)ctx.getResourceHome();
            EndpointReferenceType bankService = 
                parameters.getBankAccountEPR();
            EndpointReferenceType delegatedCredEPR =
                parameters.getDelegatedCredEPR();
            resourceKey = home.create(bankService, delegatedCredEPR);
            
        }  catch(Exception e) {
            throw new RemoteException("Error creating resource." + 
                                      e.getMessage(), e);
        }

        EndpointReferenceType epr = null;
        try {
            epr = AddressingUtils.createEndpointReference(ctx, resourceKey);
        } catch(Exception e) {
            throw new RemoteException("Error generating EPR" + e.getMessage(),
                                      e);
        }
        
        return epr;
    }

    public BigDecimal calculate(Calculate parameters) throws RemoteException {

        BigDecimal rate = parameters.getRate();
        int years = parameters.getYears();

        Object resource = null;
        try {
            resource = ResourceContext.getResourceContext().getResource();
        } catch(Exception e) {
            throw new RemoteException("Error in calculate" + e.getMessage(),
                                      e);
        }
                                      
        try {
            return ((FinanceResource)resource).calculate(rate, years);
        } catch(Exception e) {
            throw new RemoteException("Error in calculate" + e.getMessage(),
                                      e);
        } 
    }

    public BigDecimal getValue(GetValue parameters) throws RemoteException {

        BigDecimal returnParam = null;
        GlobusCredential credential= null;

        EndpointReferenceType bankAccountEPR = parameters.getBankAccountEPR();
        EndpointReferenceType delegCredEPR = parameters.getDelegatedCredEPR();
        
        /** UNCOMMENT FOR EXERCISE 10 */
        /**
        try {
           DelegationResource delegResource = 
               DelegationUtil.getDelegationResource(delegCredEPR);
           credential = delegResource.getCredential();
        } catch (DelegationException e) {
            throw new RemoteException("Error retrieving delegated credential."
                                      + e.getMessage(), e);
        }

        if (credential == null) {
            throw new RemoteException("Delegated credential is null.");
        }
        */
        /** END OF UNCOMMENT FOR EXERCISE 10 */
        return getAccountBalance(bankAccountEPR, credential);
    }


    public static BigDecimal 
        getAccountBalance(EndpointReferenceType bankAccountEPR,
                                          GlobusCredential credential) 
        throws RemoteException {


        BankServiceAddressingLocator locator =
            new BankServiceAddressingLocator();
                
        BankPortType port = null;
        try {
            port = locator.getBankPortTypePort(bankAccountEPR);
        } catch (Exception e) {
            throw new RemoteException("Error getting bank port type."
                                      + e.getMessage(), e);
        }

        GSSCredential gssCred = null;
        try {
            gssCred = 
                new GlobusGSSCredentialImpl(credential, 
                                            GSSCredential.INITIATE_AND_ACCEPT);
        } catch (Exception e) {
            throw new RemoteException("Error converting credentials."
                                      + e.getMessage(), e);
        } 

        ((Stub)port)._setProperty(Constants.GSI_SEC_CONV, 
                                  Constants.SIGNATURE);
        ((Stub)port)._setProperty(Constants.AUTHORIZATION,
                                  NoAuthorization.getInstance());
        ((Stub)port)._setProperty(GSIConstants.GSI_CREDENTIALS, gssCred);
        
        BigDecimal value = port.getCurrentBalance(new GetCurrentBalance());

        return value;
    }
}

    
