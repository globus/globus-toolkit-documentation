/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.impl.financeService;

import java.math.BigDecimal;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.Calendar;

import org.globus.wsrf.Resource;
import org.globus.wsrf.ResourceKey;
import org.globus.wsrf.ResourceIdentifier;
import org.globus.wsrf.ResourceLifetime;
import org.globus.wsrf.RemoveCallback;
import org.globus.wsrf.ResourceException;

import org.globus.wsrf.security.SecureResource;

import org.globus.wsrf.impl.security.descriptor.ResourceSecurityConfig;
import org.globus.wsrf.impl.security.descriptor.ResourceSecurityDescriptor;

import org.globus.security.gridmap.GridMap;
import org.globus.wsrf.security.SecureResource;
import org.globus.wsrf.security.SecurityManager;
import org.globus.wsrf.impl.security.descriptor.ResourceSecurityConfig;
import org.globus.wsrf.impl.security.descriptor.ResourceSecurityDescriptor;

import org.globus.wsrf.impl.security.authorization.Authorization;
import org.globus.wsrf.impl.security.authorization.ResourcePDPConfig;
import org.globus.wsrf.impl.security.authorization.IdentityAuthorization;

import javax.security.auth.Subject;

import org.globus.gsi.CertUtil;
import org.ietf.jgss.GSSCredential;
import org.globus.gsi.GlobusCredential;
import org.globus.gsi.GlobusCredentialException;
import org.globus.gsi.gssapi.GlobusGSSCredentialImpl;
import org.globus.gsi.jaas.JaasGssUtil;

import org.apache.axis.message.addressing.EndpointReferenceType;

import org.globus.delegation.DelegationUtil;
import org.globus.delegation.DelegationException;
import org.globus.delegation.DelegationListener;

import org.globus.gsi.GlobusCredential;

import java.rmi.RemoteException;

public class FinanceResource implements SecureResource, ResourceLifetime, 
                                        ResourceIdentifier {


    static Log logger =
        LogFactory.getLog(FinanceResource.class.getName());

    ResourceSecurityDescriptor desc = null;
    final String pdpPrefix = "resourcePdp";
    // Bug in GT that has this declared as protected
    final String IDENTITY_PROP = "identity";

    protected Calendar terminationTime = null;
    protected Object key;

    private EndpointReferenceType delegCredEpr;
    private EndpointReferenceType bankServiceEpr;
    private DelegationServiceListener listener;

    public FinanceResource(EndpointReferenceType bankService_, 
                           EndpointReferenceType delegEPR,
                           String descriptorFile) 
        throws Exception {

        this.bankServiceEpr = bankService_;
        this.delegCredEpr = delegEPR;

        // resource key
        this.key = new Integer(hashCode());

        if (descriptorFile == null) {
            throw new IllegalArgumentException("Descriptor file is not "
                                               + " configured");
        }

        // set up resource security descriptor such that only caller
        // can query this resource.
        ResourceSecurityConfig config = 
            new ResourceSecurityConfig(descriptorFile);
        config.init();
        this.desc = config.getSecurityDescriptor();

        /** UNCOMMENT FOR EXERCISE 10 */
        /**
        // get caller, this case creator of resource
        String caller = SecurityManager.getManager().getCaller();
        if (!caller.startsWith("/")) {
            caller = CertUtil.toGlobusID(caller, true);
        }

        String pdpChain = pdpPrefix + ":" + 
            IdentityAuthorization.class.getName();
        ResourcePDPConfig pdpConfig = new ResourcePDPConfig(pdpChain);
        pdpConfig.setProperty(Authorization.IDENTITY_PREFIX, 
                              IDENTITY_PROP, caller);
        this.desc.setAuthzChain(pdpChain, pdpConfig, null, null);

        registerListener();
        */
        /** END OF UNCOMMENT FOR EXERCISE 10 */
    }
    
    private void registerListener() throws Exception {

        /** UNCOMMENT FOR EXERCISE 10 */
        /**
        // register delegation listener for the credential
        this.listener = new DelegationServiceListener();
        DelegationUtil.registerDelegationListener(this.delegCredEpr, 
                                                  this.listener);

        // set delegated credential as resource credential
        setResourceCredential();
        */
        /** END OF UNCOMMENT FOR EXERCISE 10 */
    }

    private void setResourceCredential() throws Exception {
        
        GlobusCredential delegatedCred = this.listener.getCredential();
        setResourceCredential(delegatedCred);
    }

    private void setResourceCredential(GlobusCredential credential) 
        throws Exception {

        GSSCredential gssCred = 
            new GlobusGSSCredentialImpl(credential, 
                                        GSSCredential.INITIATE_AND_ACCEPT);
        Subject subject = JaasGssUtil.createSubject(gssCred);
        this.desc.setSubject(subject);
    }    

    
    public BigDecimal calculate(BigDecimal rate, int years) throws Exception {

        GlobusCredential delegatedCred = this.listener.getCredential();

        // set delegated credential as resource credential. It is done
        // here in case the credential has been refreshed.
        setResourceCredential(delegatedCred);

        if (delegatedCred == null) {
            throw new RemoteException("Delegated credential is null");
        }

        // get balance first
        BigDecimal balance = 
            FinanceService.getAccountBalance(this.bankServiceEpr,
                                             delegatedCred);

        // divide by 100
        rate = rate.movePointLeft(2);
        rate = rate.add(BigDecimal.valueOf(1));

        double value = Math.pow(rate.doubleValue(), years);
        BigDecimal returnVal = balance.multiply(new BigDecimal(value));
     
        return returnVal.setScale(2, BigDecimal.ROUND_HALF_UP);
    }

    // Resource Identifier Interface
    public Object getID() {
        return this.key;
    }

    // Resource Lifetime Interface
    public void setTerminationTime(Calendar time) {
        this.terminationTime = time;
    }

    // Resource Lifetime Interface
    public Calendar getTerminationTime() {
        return this.terminationTime;
    }

    // Resource Lifetime Interface
    public Calendar getCurrentTime() {
        return Calendar.getInstance();
    }

    // Secure Resource Interface
    public ResourceSecurityDescriptor getSecurityDescriptor() {
        return desc;
    }

    // Remove Callback Interface. Invoked when resource is destroyed.
    public void remove() throws ResourceException {

        try {
            this.listener.remove(this.delegCredEpr);
        } catch (DelegationException e) {
            throw new ResourceException("Error removing delegation listener"
                                        + e.getMessage(), e);
        }
    }
}
