/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.impl.financeService;

import org.globus.delegation.DelegationException;
import org.globus.delegation.DelegationListener;

import org.globus.gsi.GlobusCredential;

import org.apache.axis.message.addressing.EndpointReferenceType;

import org.globus.delegation.DelegationUtil;

public class DelegationServiceListener implements DelegationListener {

    private GlobusCredential delegatedCred = null;
    private String delegId = null;

    /**
     * Delegation Listener Interface
     * Called on regsiteration of listener and on refresh of listener
     */
    public void setCredential(GlobusCredential credential)
        throws DelegationException {
        
        this.delegatedCred = credential;
    }

    public GlobusCredential getCredential() {
        return this.delegatedCred;
    }

    /**
     * Delegation Listener Interface
     * Called on registeration of listener
     */
    public void setId(String listenerId) {
        this.delegId = listenerId;
    }
    
    /**
     * Delegation Listener Interface
     */
    public String getId() {
        return this.delegId;
    }

    /**
     * Delegation Listener Interface
     * Called when credential associated with this listener is deleted
     */
    public void credentialDeleted() {
        this.delegatedCred = null;
    }

    public void remove(EndpointReferenceType delegCredEpr) 
        throws DelegationException {

        DelegationUtil.removeDelegationListener(delegCredEpr, this.delegId);

    }
}
