/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.bank.client;

import java.math.BigDecimal;

import org.globus.axis.gsi.GSIConstants;
import org.globus.wsrf.impl.security.authentication.Constants;
import org.globus.wsrf.impl.security.authorization.NoAuthorization;

import java.util.List;

import org.globus.tutorial.bankService.BankPortType;
import org.globus.tutorial.bankService.BankServiceAddressingLocator;

import org.globus.wsrf.client.BaseClient;
import org.globus.wsrf.utils.FaultHelper;
import org.globus.axis.util.Util;

import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.CommandLine;

import javax.xml.rpc.Stub;

import java.io.FileInputStream;

import org.xml.sax.InputSource;

import org.apache.axis.message.addressing.EndpointReferenceType;

import org.globus.wsrf.encoding.ObjectDeserializer;

import java.net.URL;

public class Withdraw extends TutorialBaseClient {

    public Withdraw() {
        
        super();
        options.addOption(SERVICE_URL);
        options.addOption(BaseClient.EPR_FILE);
        options.addOption(BaseClient.DESCRIPTOR);
    }

    protected void displayUsage() {
        String usage = "java " + getClass().getName() +
            " [-h] [-d] [-f securityDescFile] -e bankServiceEprFile value ";
        System.out.println(usage);
    }
    
    protected CommandLine parse(String [] args)
        throws Exception {

        CommandLine line = super.parse(args);

        if (line.hasOption("e")) {
            this.endpoint = loadEPR(line.getOptionValue("e"));
        } else {
            throw new ParseException("-e argument is required");
        }

        return line;
    }

    public static void main(String[] args) {

        Withdraw client = new Withdraw();

        BigDecimal value = null;
        try {
            CommandLine line = client.parse(args);
            
            List options = line.getArgList();
            if (options == null || options.size() < 1) {
                client.displayUsage();
                throw new ParseException("Expected arguments");
            }
            value = new BigDecimal((String)options.get(0));
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(COMMAND_LINE_ERROR);
        }

        try {

            BankServiceAddressingLocator locator =
                new BankServiceAddressingLocator();
            
            BankPortType port = locator
                .getBankPortTypePort(client.getEPR());
            
            setSecurityProperties((Stub)port, client.getDescriptorFile());

            port.withdraw(value);

            System.out.println("Amount " + value + " withdrawn");            

        } catch(Exception e) {
            if (client.isDebugMode()) {
                FaultHelper.printStackTrace(e);
            } else {
                System.err.println("Error: " + FaultHelper.getMessage(e));
            }
            System.exit(APPLICATION_ERROR);
        }
      
    }
}
