/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.impl.bankService;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.globus.wsrf.impl.SingletonResourceHome;

import javax.xml.namespace.QName;

import org.globus.wsrf.ResourceContext;

import org.globus.wsrf.Resource;
import org.globus.wsrf.ResourceKey;
import org.globus.wsrf.ResourceHome;
import org.globus.wsrf.ResourceProperties;
import org.globus.wsrf.ResourceProperty;
import org.globus.wsrf.ResourcePropertySet;
import org.globus.wsrf.impl.SimpleResourceKey;
import org.globus.wsrf.impl.SimpleResourceProperty;
import org.globus.wsrf.impl.SimpleResourcePropertySet;

import org.apache.axis.message.addressing.EndpointReferenceType;

import javax.naming.InitialContext;

import javax.xml.soap.SOAPElement;
import org.apache.axis.message.MessageElement;
import org.apache.axis.encoding.AnyContentType;

import java.math.BigDecimal;

public class BankFactoryResource implements Resource,
                                            ResourceProperties {

    public static String NS = "http://www.globus.org/tutorial/bankFactory";
    public QName RP_SET = new QName(NS, "BankFactoryRPSet");

    ResourcePropertySet propSet;
    int numOfAccounts = 0;

    public BankFactoryResource() throws Exception {
        setResourceProperties();
    }

    // Resource properties
    public ResourcePropertySet getResourcePropertySet() {
        return this.propSet;
    }

    public EndpointReferenceType createAccount(BigDecimal initValue, 
                                               String authzDN)
        throws Exception {
        
        BankHome home = getServiceHome();
        EndpointReferenceType epr = home.createAccount(initValue, authzDN);
        numOfAccounts++;
        setResourceProperties();
        return epr;
    }

    private void setResourceProperties() throws Exception {

        this.propSet = new SimpleResourcePropertySet(RP_SET);
        this.propSet = new SimpleResourcePropertySet(RP_SET);
        QName qName = new QName(NS, "NumberOfAccounts");
        ResourceProperty prop = new SimpleResourceProperty(qName);
        prop.add(new Integer(numOfAccounts));
        this.propSet.add(prop);
    }

    protected BankHome getServiceHome() throws Exception {

        InitialContext context = new InitialContext();
        return (BankHome)context
            .lookup(org.globus.wsrf.Constants.JNDI_SERVICES_BASE_NAME +
                    BankService.SERVICE_PATH +
                    org.globus.wsrf.Constants.HOME_NAME);
    }
}
