/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.impl.bankService;

import java.math.BigDecimal;


import org.globus.tutorial.bankFactory.CreateAccountResponse;
import org.globus.tutorial.bankFactory.CreateAccount;

import java.rmi.RemoteException;

import org.globus.wsrf.ResourceContext;

import org.apache.axis.message.addressing.EndpointReferenceType;

public class BankFactoryService {

    public static BigDecimal MINIMUM_VAL = new BigDecimal(1.0);

    public CreateAccountResponse createAccount(CreateAccount request) 
        throws RemoteException {

        BigDecimal initVal = request.getInitialDeposit();

        if (initVal.compareTo(MINIMUM_VAL) < 0) {
            throw new RemoteException("Deposit cannot be less than 1");
        }

        BankFactoryResource resource = null;

        try {
            resource = (BankFactoryResource)ResourceContext
                .getResourceContext().getResource();
        }  catch(Exception e) {
            throw new RemoteException("Error creating account." + 
                                      e.getMessage(), e);
        }

        // EPR to BankService resource
        EndpointReferenceType epr = null;
        try {
            epr = resource.createAccount(initVal, request.getAuthzDN());
        } catch(Exception e) {
            throw new RemoteException("", e);
        }

        CreateAccountResponse response = new CreateAccountResponse();
        response.setEndpointReference(epr);

        return response;        
    }
}
