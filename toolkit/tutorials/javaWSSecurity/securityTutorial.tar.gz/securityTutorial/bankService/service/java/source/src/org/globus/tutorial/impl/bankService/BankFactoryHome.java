/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.impl.bankService;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.globus.wsrf.Resource;
import org.globus.wsrf.ResourceException;

import org.globus.wsrf.impl.SingletonResourceHome;

public class BankFactoryHome extends SingletonResourceHome {

    protected Resource findSingleton() throws ResourceException {

        BankFactoryResource resource = null;
        try {
            resource = new BankFactoryResource();
        } catch (Exception exp) {
            throw new ResourceException("Error creating factory resource." +
                                        exp.getMessage(), exp);
        }
        
        return resource;
    }
}
