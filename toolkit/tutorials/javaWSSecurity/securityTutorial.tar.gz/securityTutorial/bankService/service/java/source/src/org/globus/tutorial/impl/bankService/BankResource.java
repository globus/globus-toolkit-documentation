/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.impl.bankService;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.Calendar;

import org.globus.wsrf.Resource;
import org.globus.wsrf.ResourceKey;
import org.globus.wsrf.ResourceIdentifier;
import org.globus.wsrf.ResourceLifetime;

import org.globus.wsrf.security.SecureResource;

import org.globus.wsrf.impl.security.descriptor.ResourceSecurityConfig;
import org.globus.wsrf.impl.security.descriptor.ResourceSecurityDescriptor;

import org.globus.security.gridmap.GridMap;
import org.globus.wsrf.security.SecureResource;
import org.globus.wsrf.security.SecurityManager;
import org.globus.wsrf.impl.security.descriptor.ResourceSecurityConfig;
import org.globus.wsrf.impl.security.descriptor.ResourceSecurityDescriptor;

import org.globus.wsrf.impl.security.authorization.Authorization;
import org.globus.wsrf.impl.security.authorization.ResourcePDPConfig;
import org.globus.wsrf.impl.security.authorization.IdentityAuthorization;

import org.globus.gsi.CertUtil;

import java.math.BigDecimal;

public class BankResource implements SecureResource, ResourceLifetime, 
                                     ResourceIdentifier {

    static Log logger =
        LogFactory.getLog(BankResource.class.getName());

    ResourceSecurityDescriptor desc = null;
    final String pdpPrefix = "bankResPdp";
    // Bug in GT that has this declared as protected
    final String IDENTITY_PROP = "identity";

    protected Calendar terminationTime = null;
    protected Object key;

    private BigDecimal balance;

    public BankResource() {
        this.key = new Integer(hashCode());
    }

    public void init(BigDecimal initValue, String authzDN_, 
                     String descriptorFile) throws Exception {

        if (descriptorFile == null) {
            throw new IllegalArgumentException("Descriptor file is not "
                                               + " configured");
        }

        // round off to two digits:
        this.balance = initValue.setScale(2, BigDecimal.ROUND_HALF_UP);

        if (!authzDN_.startsWith("/")) {
            authzDN_ = CertUtil.toGlobusID(authzDN_, true);
        }

        // set up resource security descriptor such that only authzDN_
        // can query this resource.
        ResourceSecurityConfig config = 
            new ResourceSecurityConfig(descriptorFile);
        config.init();
        this.desc = config.getSecurityDescriptor();

        /** UNCOMMENT FOR EXERCISE 9 */
        /**
        String pdpChain = pdpPrefix + ":" + 
            IdentityAuthorization.class.getName();
        ResourcePDPConfig pdpConfig = new ResourcePDPConfig(pdpChain);
        pdpConfig.setProperty(Authorization.IDENTITY_PREFIX, 
                              IDENTITY_PROP, authzDN_);
        this.desc.setAuthzChain(pdpChain, pdpConfig, null, null);
        */
        /** END OF UNCOMMENT FOR EXERCISE 9 */
    }
    
    public synchronized void deposit(BigDecimal data) {
        
        this.balance = 
            this.balance.add(data.setScale(2, BigDecimal.ROUND_HALF_UP));
    }

    public synchronized void withdraw(BigDecimal data) throws Exception {

        if (data.compareTo(this.balance) > 0) {
            throw new Exception("Insufficient funds");
        }
        this.balance = 
            this.balance.subtract(data.setScale(2, BigDecimal.ROUND_HALF_UP));
    }
    
    public BigDecimal getValue() {
        return this.balance;
    }

    public Object getID() {
        return this.key;
    }

    public void setTerminationTime(Calendar time) {
        this.terminationTime = time;
    }

    public Calendar getTerminationTime() {
        return this.terminationTime;
    }

    public Calendar getCurrentTime() {
        return Calendar.getInstance();
    }

    public ResourceSecurityDescriptor getSecurityDescriptor() {
        return desc;
    }
}
