/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.impl.bankService;


import org.globus.tutorial.bankService.DepositResponse;
import org.globus.tutorial.bankService.WithdrawResponse;
import org.globus.tutorial.bankService.GetCurrentBalance;

import java.rmi.RemoteException;

import org.globus.wsrf.ResourceContext;

import java.math.BigDecimal;

public class BankService {

    public static String SERVICE_PATH = "BankService";
    public static BigDecimal MINIMUM_VAL = new BigDecimal(1.0);

    public BigDecimal getCurrentBalance(GetCurrentBalance parameters) 
        throws RemoteException {
        
        BankResource resource = null;
        
        try {
            resource = (BankResource)ResourceContext
                .getResourceContext().getResource();
        }  catch(Exception e) {
            throw new RemoteException("Error creating account." + 
                                      e.getMessage(), e);
        }

        return resource.getValue();
    }

    public DepositResponse deposit(BigDecimal amount) throws RemoteException {

        if (amount.compareTo(MINIMUM_VAL) < 0) {
            throw new RemoteException("Deposit cannot be less than 1");
        }

        BankResource resource = null;
        
        try {
            resource = (BankResource)ResourceContext
                .getResourceContext().getResource();
        }  catch(Exception e) {
            throw new RemoteException("Error creating account." + 
                                      e.getMessage(), e);
        }

        resource.deposit(amount);

        return new DepositResponse();
    }

    public WithdrawResponse withdraw(BigDecimal parameters) 
        throws RemoteException {

        BankResource resource = null;
        
        try {
            resource = (BankResource)ResourceContext
                .getResourceContext().getResource();
            resource.withdraw(parameters);
        }  catch(Exception e) {
            throw new RemoteException("Error creating account." + 
                                      e.getMessage(), e);
        }
        
        return new WithdrawResponse();
    }
}

    
