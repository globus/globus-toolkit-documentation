/*
 * Portions of this file Copyright 1999-2005 University of Chicago
 * Portions of this file Copyright 1999-2005 The University of Southern California.
 *
 * This file or a portion of this file is licensed under the
 * terms of the Globus Toolkit Public License, found at
 * http://www.globus.org/toolkit/download/license.html.
 * If you redistribute this file, with or without
 * modifications, you must include this notice in the file.
 */
package org.globus.tutorial.impl.bankService;

import java.net.URL;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.globus.wsrf.ResourceKey;
import org.globus.wsrf.impl.ResourceHomeImpl;
import org.globus.wsrf.impl.SimpleResourceKey;

import org.globus.wsrf.container.ServiceHost;

import org.globus.wsrf.utils.AddressingUtils;

import org.apache.axis.message.addressing.EndpointReferenceType;

import java.math.BigDecimal;

public class BankHome extends ResourceHomeImpl {

    private String descriptorFile = null;

    static Log logger =
        LogFactory.getLog(BankHome.class.getName());

    public EndpointReferenceType createAccount(BigDecimal initValue, 
                                               String authzDN)
        throws Exception {

        BankResource resource = (BankResource)createNewInstance();
        resource.init(initValue, authzDN, this.descriptorFile);
        ResourceKey key = new SimpleResourceKey(keyTypeName,
                                                resource.getID());
        add(key, resource);

        URL baseURL = ServiceHost.getBaseURL();
        String serviceURI = baseURL.toString() + 
            BankService.SERVICE_PATH;;
        return AddressingUtils.createEndpointReference(serviceURI, key);
    }

    public void setSecurityDescriptor(String descriptorFile) {
        this.descriptorFile = descriptorFile;
    }

    public String getSecurityDescriptor() {
        return this.descriptorFile;
    }
}
