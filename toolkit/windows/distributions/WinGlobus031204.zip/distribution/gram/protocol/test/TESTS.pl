#!/usr/bin/env perl

exit system('./globus-gram-protocol-run-tests.pl');


