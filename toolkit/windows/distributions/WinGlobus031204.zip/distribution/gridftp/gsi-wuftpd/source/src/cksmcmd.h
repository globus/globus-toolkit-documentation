#include <globus_ftp_control.h>

void cksmcmd(char *filename,
	     char *algorithm,
	     globus_off_t offset,
	     globus_off_t length);
