Notes on OpenSSL
3/12/2004


Install and build OpenSSL per the notes with that distribution. This will create the def files, binaries and executables. 

Once this is done go to the .\ms directory in the OpenSSL tree and replace the def files there with those provided in this directory. 

Then rebuild by invoking the makefile. I think this must be done from the directory above using:

	nmake ms\nt.mak 

but I haven't done this for a while so you may have to play with it. Also you may have to delete the dlls to force a relink.

The additional symbols needed by GSI should now be defined as exports.

Bob Gaffaney
gaffaney@mcs.anl.gov