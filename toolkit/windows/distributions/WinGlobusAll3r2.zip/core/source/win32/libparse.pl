
system "nm libglobus_common_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_common_.exports")) {
    print "Can't Open libglobus_common_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_callout_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_callout_.exports")) {
    print "Can't Open libglobus_callout_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_proxy_ssl_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_proxy_ssl_.exports")) {
    print "Can't Open libglobus_proxy_ssl_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_openssl_error_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_openssl_error_.exports")) {
    print "Can't Open libglobus_openssl_error_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_openssl_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_openssl_.exports")) {
    print "Can't Open libglobus_openssl_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gsi_sysconfig_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gsi_sysconfig_.exports")) {
    print "Can't Open libglobus_gsi_sysconfig_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gsi_cert_utils_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gsi_cert_utils_.exports")) {
    print "Can't Open libglobus_gsi_cert_utils_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_oldgaa_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_oldgaa_.exports")) {
    print "Can't Open libglobus_oldgaa_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gsi_callback_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gsi_callback_.exports")) {
    print "Can't Open libglobus_gsi_callback_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gsi_credential_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gsi_credential_.exports")) {
    print "Can't Open libglobus_gsi_credential_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gsi_proxy_core_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gsi_proxy_core_.exports")) {
    print "Can't Open libglobus_gsi_proxy_core_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gssapi_gsi_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gssapi_gsi_.exports")) {
    print "Can't Open libglobus_gssapi_gsi_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gss_assist_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gss_assist_.exports")) {
    print "Can't Open libglobus_gss_assist_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libgssapi_error_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libgssapi_error_.exports")) {
    print "Can't Open libgssapi_error_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gridmap_callout_error_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gridmap_callout_error_.exports")) {
    print "Can't Open libglobus_gridmap_callout_error_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gridmap_callout_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gridmap_callout_.exports")) {
    print "Can't Open libglobus_gridmap_callout_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_io_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_io_.exports")) {
    print "Can't Open libglobus_io_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_ftp_control_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_ftp_control_.exports")) {
    print "Can't Open libglobus_ftp_control_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_ftp_client_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_ftp_client_.exports")) {
    print "Can't Open libglobus_ftp_client_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gass_transfer_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gass_transfer_.exports")) {
    print "Can't Open libglobus_gass_transfer_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gass_copy_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gass_copy_.exports")) {
    print "Can't Open libglobus_gass_copy_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gass_server_ez_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gass_server_ez_.exports")) {
    print "Can't Open libglobus_gass_server_ez_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gram_protocol_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gram_protocol_.exports")) {
    print "Can't Open libglobus_gram_protocol_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);


system "nm libglobus_gram_client_gcc32dbgpthr.so \> temp.symbols";
 
if(!open(SYMBOLS,"temp.symbols")) {
    print "Can't Open temp.symbols\n";
    exit();
    }

if(!open(EXPORTS,'>',"libglobus_gram_client_.exports")) {
    print "Can't Open libglobus_gram_client_.exports\n";
    exit();
    }

while (<SYMBOLS>) {
    @temp = split;
    if($temp[1] eq "T") {
        print EXPORTS "$temp[2]\n";
        }
    if($temp[1] eq "D") {
        print EXPORTS "$temp[2]\n";
        }
    }

close(SYMBOLS);
system "rm temp.symbols";
 
close(EXPORTS);

