#ifndef GLOBUS_DONT_DOCUMENT_INTERNAL
/**
 * @file globus_i_error_errno.h
 * Globus Errno Error
 *
 * $RCSfile: globus_i_error_errno.h,v $
 * $Revision: 1.2 $
 * $Date $
 */

#include "globus_common_include.h"

#ifndef GLOBUS_I_INCLUDE_ERRNO_ERROR_H
#define GLOBUS_I_INCLUDE_ERRNO_ERROR_H


EXTERN_C_BEGIN

EXTERN_C_END

#endif /* GLOBUS_I_INCLUDE_ERRNO_ERROR_H */

#endif /* GLOBUS_DONT_DOCUMENT_INTERNAL */
