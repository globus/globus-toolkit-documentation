#!/usr/bin/env perl

exit (0 != system('./globus-ftp-client-run-tests.pl -runserver'));
