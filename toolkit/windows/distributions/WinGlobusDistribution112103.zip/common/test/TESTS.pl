#!/usr/bin/env perl

exit system('./run-common-tests.pl');


