#!/usr/bin/env perl

exit system('./globus-gram-job-manager-run-tests.pl');


