#!/usr/bin/env perl

exit system('./globus-gram-client-run-tests.pl');


