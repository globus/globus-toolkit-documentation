static
globus_version_t local_version = 
{
    2,
    1,
    1020870347,
    8
};