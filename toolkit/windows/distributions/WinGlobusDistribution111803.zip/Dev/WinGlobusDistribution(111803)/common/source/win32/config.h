/* 
 * config.h.win  
 * for WIN32 copy file to config.h
 */

