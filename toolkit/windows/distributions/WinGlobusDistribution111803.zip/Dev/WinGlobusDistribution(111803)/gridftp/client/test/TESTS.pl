#!/usr/bin/env perl

exit system('./globus-ftp-client-run-tests.pl -runserver');

exit 0;
