/*
globus_i_gram_client.h

CVS Information:
    $Source: /home/globdev/CVS/globus-packages/gram/client/source/globus_i_gram_client.h,v $
    $Date: 2003/03/10 16:13:13 $
    $Revision: 1.2 $
    $Author: bester $
*/

#ifndef GLOBUS_I_I_GRAM_CLIENT_INCLUDE
#define GLOBUS_I_I_GRAM_CLIENT_INCLUDE

#include "globus_gram_client.h"

EXTERN_C_BEGIN

/******************************************************************************
                               Type definitions
******************************************************************************/
typedef struct
{
    gss_cred_id_t                   credential;
}
globus_i_gram_client_attr_t;

EXTERN_C_END
#endif /* GLOBUS_I_I_GRAM_CLIENT_INCLUDE */

