#! /bin/sh

CVSLOC=:pserver:anonymous@cvs.globus.org:/home/globdev/CVS/globus-packages
DATE="2006-07-13"

cvs -d $CVSLOC rdiff -u -D $DATE -r campaign_b4453_branch wsrf/java/core/source/deploy-server.wsdd wsrf/java/core/source/deploy-jndi-config.xml wsrf/java/core/source/build.xml wsrf/java/core/source/etc/post-deploy.xml wsrf/java/tools/source/share/build-stubs.xml wsrf/java/core/source/src/org/globus/wsrf/utils/FilePersistenceHelper.java > enum.patch

cvs -d $CVSLOC rdiff -u -r globus_4_0_branch -r HEAD wsrf/java/core/source/src/org/globus/wsrf/utils/AdapterProxy.java wsrf/java/core/source/src/org/globus/wsrf/TerminationTimeRejectedException.java >> enum.patch

cvs -d $CVSLOC rdiff -u -D $DATE -r campaign_b4453_branch wsrf/schema/ws/enumeration wsrf/java/core/source/src/org/globus/ws wsrf/java/core/source/src/org/globus/wsrf/utils/io/ wsrf/java/core/source/src/org/globus/axis/utils/DurationUtils.java >> enum.patch

cvs -d $CVSLOC rdiff -u -D $DATE -r campaign_b4453_branch wsrf/schema/core/samples/enumeration/ wsrf/java/core/samples/enumeration/ > enum.sample.patch

cvs -d $CVSLOC rdiff -u -D $DATE -r campaign_b4453_branch wsrf/java/core/test/unit/src/org/globus/ws/ wsrf/java/core/test/unit/src/org/globus/axis/ wsrf/schema/core/tests/enumeration/ wsrf/java/core/test/unit/deploy-server.wsdd wsrf/java/core/test/unit/deploy-jndi-config.xml > enum.test.patch

