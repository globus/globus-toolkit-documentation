#!/bin/bash

INTERFACE_PATH=$1

if [ ! -e $INTERFACE_PATH -o ! -f $INTERFACE_PATH ]
then
    echo "$INTERFACE_PATH does not exist or is not a file."
    exit 1;
fi

PATH_AUX=$(echo $INTERFACE_PATH | cut -f 1 -d .)
DESCRIPTION_TYPE=$(echo $INTERFACE_PATH | cut -f 2 -d .)

IFS=/
set -- $*
NUM_FIELDS=$#

i=1
for n in $PATH_AUX
do
    if [ $i -eq 1 ]
    then
	PACKAGE=$n
	NAMESPACE="$n"	
    else
	if [ $i -eq $NUM_FIELDS ]
	then
	    INTERFACE=$n
	else
	    if [ $i -lt $[NUM_FIELDS-1] ]
	    then
		    NAMESPACE="$n.$NAMESPACE"
	    PACKAGE="$PACKAGE.$n"
	    fi	
	fi
    fi
    i=$[i+1]
done
IFS=""

#PACKAGE_DIR=$(echo $PACKAGE | sed s/\.impl//g)
PACKAGE_DIR=$(echo $PACKAGE | sed "s/\./\//g")

case $DESCRIPTION_TYPE in
"java")
	ant -Djava.interface=true -Dpackage=$PACKAGE -Dinterface.name=$INTERFACE -Dpackage.dir=$PACKAGE_DIR -Dservices.namespace=$NAMESPACE
	;;
"gwsdl")
	ant -Dgwsdl.interface=true -Dpackage=$PACKAGE -Dinterface.name=$INTERFACE -Dpackage.dir=$PACKAGE_DIR
	;;
*)
	"$INTERFACE_PATH must be a Java interface or a GWSDL description."
esac
