#ifndef __CONFIG_H
#define __CONFIG_H
@TOP@

#undef GGLV_MAJOR
#undef GGLV_MINOR
#undef GGLV_SUB
#undef GGLV_PRE

#undef HAVE_THREADS

#undef GGLV_DEBUG

/* Define this if you're running x86 architecture */
#undef __i386__

/* Define this if you're running x86 architecture */
#undef ARCH_X86

/* Define this if you're running Alpha architecture */
#undef __alpha__

/* Define this if you're running PowerPC architecture */
#undef ARCH_PPC

/* Define this if you're running Sparc architecture */
#undef __sparc__ 

/* Define this if you're running Mips architecture */
#undef __mips__ 

@BOTTOM@
/* Disable GCC compiler extensions, if gcc is not in use */
#ifndef __GNUC__
#define __attribute__(x)        /*empty*/
#endif

#endif /* __CONFIG_H */
